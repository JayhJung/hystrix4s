package rest4s.config;

public enum RequestType {
	GET,POST, PUT, DELETE
}
