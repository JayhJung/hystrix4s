This package is not part of the public API and can change at any time. Do not rely upon any classes in this package.

The public API is com.netflix.hystrix.HystrixCollapser